<?php
header('Location: study657585.php');
?>