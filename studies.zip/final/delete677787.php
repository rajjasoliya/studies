<?php
include_once('connect.php');
$redis->flushAll();
header('Location: study657585.php');
?>
